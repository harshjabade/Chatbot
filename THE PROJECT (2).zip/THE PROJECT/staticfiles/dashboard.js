let isVoiceEnabled = false;
let currentUtterance = null;
let currentText = '';
let spokenIndex = 0;

// Automatically adjust the height of the textarea based on content
const userInput = document.getElementById('user-input');
userInput.addEventListener('input', function() {
    // Set height to auto to calculate scrollHeight
    this.style.height = 'auto';
    
    // Adjust height if the scrollHeight exceeds the clientHeight
    if (this.scrollHeight > this.clientHeight) {
        this.style.height = `${Math.min(this.scrollHeight, 100)}px`;
    }
});

// Send message when Enter key is pressed without Shift
userInput.addEventListener('keydown', function(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault(); // Prevent adding a new line
        sendMessage();
    }
});

// function sendMessage() {
//     const message = userInput.value.trim();

//     if (message === "") return;

//     appendMessage('You', message, 'user-message');

//     userInput.value = '';
//     userInput.style.height = '20px'; // Reset height after sending

//     fetch('http://127.0.0.1:5000/get_response', {
//         method: 'POST',
//         headers: {
//             'Content-Type': 'application/json'
//         },
//         body: JSON.stringify({ user_input: message })
//     })
//     .then(response => response.json())
//     .then(data => {
//         appendMessage('Ai', data.response, 'ai-message');
        
//         currentText = data.response;
//         spokenIndex = 0;

//         saveToHistory(message, data.response);

//         if (isVoiceEnabled) {
//             speak(currentText);
//         }
//     })
//     .catch(error => {
//         appendMessage('Bot', 'Oops your internet connection is poor.', 'ai-message');
//         console.error(error);
//     });
// }

function toggleVoice() {
    isVoiceEnabled = !isVoiceEnabled;
    const toggleButton = document.getElementById('voice-toggle-btn').querySelector('img');
    toggleButton.src = isVoiceEnabled ? '/myproject/static/volume.png' : '/myproject/ststic/mute.png';

    if (isVoiceEnabled && currentText) {
        speak(currentText.substring(spokenIndex));
    } else if (!isVoiceEnabled && window.speechSynthesis.speaking) {
        window.speechSynthesis.cancel();
    }
}

function speak(text) {
    if ('speechSynthesis' in window) {
        currentUtterance = new SpeechSynthesisUtterance(text);
        currentUtterance.onend = function() {
            spokenIndex = currentText.length;
        };
        currentUtterance.onboundary = function(event) {
            if (event.name === 'word') {
                spokenIndex = event.charIndex;
            }
        };
        window.speechSynthesis.speak(currentUtterance);
    } else {
        console.error('Text-to-Speech not supported in this browser.');
    }
}

function appendMessage(sender, message, messageClass) {
    const chatBox = document.getElementById('chat-box');
    const messageElement = document.createElement('div');
    messageElement.classList.add('message', messageClass);
    messageElement.textContent = `${sender}: ${message}`;
    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight;
}

function saveToHistory(userMessage, aiResponse) {
    const sidebar = document.getElementById('sidebar');
    const historyItem = document.createElement('div');
    historyItem.classList.add('history-item');
    historyItem.textContent = `You: ${userMessage}`;
    historyItem.addEventListener('click', function() {
        appendMessage('You', userMessage, 'user-message');
        appendMessage('Ai', aiResponse, 'ai-message');
    });
    sidebar.appendChild(historyItem);
}


