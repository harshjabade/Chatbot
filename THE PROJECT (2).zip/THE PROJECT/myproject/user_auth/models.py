from django.db import models
from django.contrib.auth.models import User
from django.utils.timezone import now

class LoginRecord(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)  # Link to the Django User model
    login_time = models.DateTimeField(default=now)  # Time of login
    ip_address = models.GenericIPAddressField(null=True, blank=True)  # IP address of the user

    def __str__(self):
        return f"{self.user.username} logged in at {self.login_time}"

from django.db import models
from django.contrib.auth.models import User
import datetime

class OTP(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    otp = models.CharField(max_length=6)
    created_at = models.DateTimeField(auto_now_add=True)

    def is_expired(self):
        """Check if the OTP is expired (valid for 5 minutes)."""
        expiry_time = self.created_at + datetime.timedelta(minutes=5)
        return datetime.datetime.now(datetime.timezone.utc) > expiry_time
    
from django.db import models
from django.contrib.auth.models import User

class ChatSession(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    session_name = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('user', 'session_name')
        ordering = ['-updated_at']

    def __str__(self):
        return f"{self.user.username}: {self.session_name}"

class ChatMessage(models.Model):
    session = models.ForeignKey(ChatSession, related_name='messages', on_delete=models.CASCADE)
    user_message = models.TextField()
    ai_response = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['timestamp']

    def __str__(self):
        return f"Message in {self.session.session_name} at {self.timestamp}"
 