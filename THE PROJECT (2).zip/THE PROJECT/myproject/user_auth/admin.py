
from django.contrib import admin
from .models import ChatSession, ChatMessage

class ChatMessageInline(admin.TabularInline):
    model = ChatMessage
    extra = 0
    readonly_fields = ('timestamp',)
    fields = ('timestamp', 'user_message', 'ai_response')

@admin.register(ChatSession)
class ChatSessionAdmin(admin.ModelAdmin):
    list_display = ('user', 'session_name', 'created_at', 'updated_at')
    list_filter = ('user', 'created_at')
    search_fields = ('session_name', 'user__username')
    inlines = [ChatMessageInline]

@admin.register(ChatMessage)
class ChatMessageAdmin(admin.ModelAdmin):
    list_display = ('session', 'short_user_message', 'short_ai_response', 'timestamp')
    list_filter = ('session__user', 'session', 'timestamp')
    search_fields = ('user_message', 'ai_response', 'session__session_name')

    def short_user_message(self, obj):
        return obj.user_message[:50] + '...' if len(obj.user_message) > 50 else obj.user_message
    short_user_message.short_description = 'User Message'

    def short_ai_response(self, obj):
        return obj.ai_response[:50] + '...' if len(obj.ai_response) > 50 else obj.ai_response
    short_ai_response.short_description = 'AI Response'