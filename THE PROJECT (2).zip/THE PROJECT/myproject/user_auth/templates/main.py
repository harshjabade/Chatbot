from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import google.generativeai as genai
import importlib.util
from datetime import datetime
import json
from Traning import load_prompt_module

app = Flask(__name__)
CORS(app)

# Configure Gemini API
API_KEY = "AIzaSyB6Js36l_FkjI81cSD-MgIO4wuHUaxDaEs"
genai.configure(api_key=API_KEY)

# AI Model Configuration
generation_config = {
    "temperature": 0.7,
    "top_p": 0.9,
    "top_k": 40,
    "max_output_tokens": 8192,
    "response_mime_type": "text/plain",
}

# Load AI Model
model = genai.GenerativeModel(
    model_name="gemini-2.0-flash",
    generation_config=generation_config,
)

# Session storage (in-memory, consider database for production)
sessions = {}

# def load_prompt_module(prompt_type):
#     """Dynamically load the prompt module based on user selection"""
#     prompt_mapping = {
#         'general': 'Your name is Codo, knowledgeable general assistant.',
#         'technical': 'You are a technical expert specializing in computers and programming.',
#         'creative': 'You are a creative writing assistant skilled in storytelling.',
#         'medical': 'You are a medical information assistant (NOT a doctor). Always remind users to consult healthcare professionals.'
#     }
#     return prompt_mapping.get(prompt_type, prompt_mapping['general'])

def save_session(user_id, session_name, user_message, ai_response):
    """Save conversation to session storage"""
    if user_id not in sessions:
        sessions[user_id] = {}
    if session_name not in sessions[user_id]:
        sessions[user_id][session_name] = {
            'created_at': datetime.now().isoformat(),
            'messages': []
        }
    
    sessions[user_id][session_name]['messages'].extend([
        {'role': 'user', 'content': user_message, 'timestamp': datetime.now().isoformat()},
        {'role': 'assistant', 'content': ai_response, 'timestamp': datetime.now().isoformat()}
    ])

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_input = data.get("user_input", "").strip()
    user_id = data.get("user_id", "default_user")
    session_name = data.get("session_name", "default_session")
    prompt_type = data.get("prompt_type", "general")
    custom_prompt = data.get("custom_prompt")

    if not user_input:
        return jsonify({"response": "Please enter a message."})

    try:
        if prompt_type == "custom" and custom_prompt:
            system_prompt = custom_prompt
        else:
            system_prompt = load_prompt_module(prompt_type)
        
        response = model.generate_content([
            system_prompt,
            f"User: {user_input}",
            "AI:"
        ])
        
        # Format code examples in response with triple backticks
        response_text = response.text.strip()
        
        # Save to session
        save_session(user_id, session_name, user_input, response_text)
        
        return jsonify({
            "response": response_text,
            "status": "success",
            "timestamp": datetime.now().isoformat()
        })

    except Exception as e:
        app.logger.error(f"Error in chat endpoint: {str(e)}")
        return jsonify({
            "response": "Oops! Something went wrong. Please try again.",
            "status": "error",
            "timestamp": datetime.now().isoformat()
        }), 500
    
@app.route("/sessions/<user_id>", methods=["GET"])
def get_sessions(user_id):
    """Endpoint to retrieve user sessions"""
    try:
        user_sessions = sessions.get(user_id, {})
        return jsonify({
            "sessions": user_sessions,
            "status": "success"
        })
    except Exception as e:
        return jsonify({
            "error": str(e),
            "status": "error"
        }), 500



if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)