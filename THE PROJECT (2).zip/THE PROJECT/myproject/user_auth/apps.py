
from django.apps import AppConfig
from flask import app, jsonify, request

class UserAuthConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'user_auth'  # The app name



