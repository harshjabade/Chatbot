from django.db.models.signals import post_delete
from django.dispatch import receiver
from .models import ChatSession

@receiver(post_delete, sender=ChatSession)
def delete_empty_sessions(sender, instance, **kwargs):
    # This is just an example - you might want to implement different cleanup logic
    pass