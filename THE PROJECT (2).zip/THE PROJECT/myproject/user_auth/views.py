from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
import random
from django.core.mail import send_mail
from .models import OTP

def signup(request):
    if request.method == 'POST':
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')
        password = request.POST.get('password')

        # Check if the email already exists
        if User.objects.filter(username=email).exists():
            messages.error(request, 'Email is already registered. Please log in.')
            return redirect('login_user')

        # Create the user
        user = User.objects.create_user(
            username=email,
            email=email,
            password=password,
            first_name=first_name,
            last_name=last_name
        )
        messages.success(request, 'Sign-Up successful. Please log in.')
        return redirect('login_user')

    return render(request, 'signup.html')  # Render the sign-up page


from django.contrib.auth.decorators import login_required, user_passes_test
from django.views.decorators.csrf import csrf_exempt
from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect

def is_admin(user):
    return user.is_staff or user.is_superuser

@csrf_exempt
def login_user(request):
    if request.method == "POST":
        email = request.POST.get("email")
        password = request.POST.get("password")

        user = authenticate(request, username=email, password=password)

        if user is not None:
            login(request, user)
            
            # Check if user has admin permissions
            if is_admin(user):
                return redirect("admin_dashboard")  # Redirect to admin dashboard
            else:
                return redirect("dashboard")  # Redirect to regular user dashboard
        else:
            messages.error(request, "Invalid email or password. Please try again.")

    return render(request, "login.html")

# Protect admin dashboard with admin permission check
@login_required
@user_passes_test(is_admin)
def admin_dashboard(request):
    return render(request, "admin_dashboard.html")

# Dashboard View
def dashboard(request):
    if request.user.is_authenticated:
        return render(request, 'dashboard.html')  # Show dashboard if user is logged in
    else:
        return redirect('login_user')  # Redirect to login if user is not logged in


@login_required
def dashboard(request):
    print(f"Accessing dashboard: {request.user}")  # Debug log
    return render(request, 'dashboard.html')


# Logout View
def logout_user(request):
    logout(request) # type: ignore
    messages.success(request, 'You have been logged out successfully.')
    return redirect('login_user')


def forgot_password(request):
    if request.method == "POST":
        email = request.POST.get("email")

        # Check if user exists
        user = User.objects.filter(email=email).first()
        if not user:
            messages.error(request, "This email is not registered.")
            return redirect("forgot")

        # Prevent multiple OTP requests within 5 minutes
        last_otp = OTP.objects.filter(user=user).order_by("-created_at").first()
        if last_otp and not last_otp.is_expired():
            messages.error(request, "OTP already sent. Please wait 5 minutes before requesting again.")
            return redirect("forgot")

        # Generate a new OTP
        otp_code = str(random.randint(100000, 999999))
        OTP.objects.create(user=user, otp=otp_code)

        # Send OTP via email
        send_mail(
            "Password Reset OTP",
            f"Your OTP for password reset is: {otp_code}",
            "your-email@gmail.com",
            [email],
            fail_silently=False,
        )

        messages.success(request, "OTP sent to your email. Please enter it to reset your password.")
        return redirect("verifyOtp", email=email)  # Pass email as a URL parameter

    return render(request, 'user_auth/forgot.html')




def verify_otp(request, email):
    if request.method == "POST":
        otp_entered = request.POST.get("otp")

        user = User.objects.filter(email=email).first()
        if not user:
            messages.error(request, "Invalid email.")
            return redirect("forgot")

        # Get latest OTP
        latest_otp = OTP.objects.filter(user=user).order_by("-created_at").first()
        if not latest_otp:
            messages.error(request, "No OTP found. Request a new one.")
            return redirect("forgot")

        if latest_otp.is_expired():
            messages.error(request, "OTP expired. Request a new one.")
            return redirect("forgot")

        if latest_otp.otp != otp_entered:
            messages.error(request, "Invalid OTP. Please try again.")
            return redirect("verifyOtp", email=email)

        messages.success(request, "OTP verified. Please reset your password.")
        return redirect("reset", email=email)

    return render(request, "verifyOtp.html", {"email": email})


def reset_password(request, email):
    if request.method == "POST":
        new_password = request.POST.get("password")

        user = User.objects.filter(email=email).first()
        if user:
            user.set_password(new_password)
            user.save()
            messages.success(request, "Password reset successful. Please login.")
            return redirect("login_user")
        else:
            messages.error(request, "Something went wrong. Please try again.")

    return render(request, "reset.html", {"email": email})

def home(request):
    return render(request, 'user_auth/home.html')


import json
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import login_required
from .models import ChatSession, ChatMessage
from django.shortcuts import get_object_or_404

@csrf_exempt
@login_required
def chat_api(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            action = data.get('action')
            
            if action == 'save':
                return save_chat(request, data)
            elif action == 'load':
                return load_chat(request, data)
            elif action == 'list':
                return list_sessions(request)
            elif action == 'delete':
                return delete_session(request, data)
            else:
                return JsonResponse({'status': 'error', 'message': 'Invalid action'}, status=400)
                
        except json.JSONDecodeError:
            return JsonResponse({'status': 'error', 'message': 'Invalid JSON'}, status=400)
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=500)
    
    return JsonResponse({'status': 'error', 'message': 'Invalid request method'}, status=405)

def save_chat(request, data):
    user = request.user
    session_name = data.get('session_name')
    user_message = data.get('user_message')
    ai_response = data.get('ai_response')

    session, created = ChatSession.objects.get_or_create(
        user=user,
        session_name=session_name,
        defaults={'session_name': session_name}
    )

    ChatMessage.objects.create(
        session=session,
        user_message=user_message,
        ai_response=ai_response
    )

    return JsonResponse({
        'status': 'success',
        'session': {
            'name': session.session_name,
            'updated_at': session.updated_at.isoformat()
        }
    })

def load_chat(request, data):
    user = request.user
    session_name = data.get('session_name')
    
    session = get_object_or_404(ChatSession, user=user, session_name=session_name)
    messages = session.messages.all().order_by('timestamp')
    
    return JsonResponse({
        'status': 'success',
        'session': session.session_name,
        'messages': [
            {
                'user': msg.user_message,
                'ai': msg.ai_response,
                'timestamp': msg.timestamp.isoformat()
            } for msg in messages
        ]
    })

def list_sessions(request):
    sessions = ChatSession.objects.filter(user=request.user).order_by('-updated_at')
    
    return JsonResponse({
        'status': 'success',
        'sessions': [
            {
                'name': session.session_name,
                'created_at': session.created_at.isoformat(),
                'updated_at': session.updated_at.isoformat(),
                'message_count': session.messages.count()
            } for session in sessions
        ]
    })

def delete_session(request, data):
    session_name = data.get('session_name')
    session = get_object_or_404(ChatSession, user=request.user, session_name=session_name)
    session.delete()
    
    return JsonResponse({
        'status': 'success',
        'message': f'Session "{session_name}" deleted'
    })