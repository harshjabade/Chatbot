# user_auth/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.login_user, name='login_user'),  # Custom login page
    path('signup/', views.signup, name='signup'),  # Signup page
    path('dashboard/', views.dashboard, name='dashboard'),
    path('logout/', views.logout_user, name='logout_user'),
    path('home/', views.home, name='home'),
    path('api/chat/', views.chat_api, name='chat_api'),
    

    path("forgot-password/", views.forgot_password, name="forgot"),
    path("verifyOtp/<str:email>/", views.verify_otp, name="verifyOtp"),
    path("reset/<str:email>/", views.reset_password, name="reset"),
    

]


