let isVoiceEnabled = false;
let currentUtterance = null;
let currentText = '';
let spokenIndex = 0;
let currentPromptType = 'general';
let customPromptText = localStorage.getItem('customPrompt') || '';
// Load user-specific sessions from localStorage
let userId = localStorage.getItem('userId');
if (!userId) {
    userId = `user_${Date.now()}`; // Generate a unique user ID
    localStorage.setItem('userId', userId);
}

let chatSessions = JSON.parse(localStorage.getItem(`chatSessions_${userId}`)) || {}; // Load sessions
let activeSession = localStorage.getItem(`activeSession_${userId}`) || 'Default';

// Initialize active session if not present
if (!chatSessions[activeSession]) {
    chatSessions[activeSession] = [];
    localStorage.setItem(`chatSessions_${userId}`, JSON.stringify(chatSessions));
}

// Automatically adjust the height of the textarea
const userInput = document.getElementById('user-input');
userInput.addEventListener('input', function () {
    this.style.height = 'auto';
    this.style.height = `${Math.min(this.scrollHeight, 100)}px`;
});

// Send message on Enter key (without Shift)
userInput.addEventListener('keydown', function (event) {
    if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        sendMessage();
    }
});

// // Send Message Function
// function sendMessage() {
//     const message = userInput.value.trim();
//     if (message === "") return;

//     appendMessage('You', message, 'user-message');
//     userInput.value = '';
//     userInput.style.height = 'auto'; // Reset height to auto
//     userInput.style.height = `${userInput.scrollHeight}px`; // Set height based on content

//     fetch('http://127.0.0.1:5000/chat', {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify({
//             user_input: message,
//             user_id: userId,
//             session_name: activeSession
//         })
//     })
//     .then(response => {
//         if (!response.ok) {
//             throw new Error(`HTTP error! Status: ${response.status}`);
//         }
//         return response.json();
//     })
//     .then(data => {
//         console.log("Response Data:", data); // Debug: Log the response data
//         appendMessage('AI', data.response, 'ai-message');

//         currentText = data.response;
//         spokenIndex = 0;

//         saveToSession(message, data.response);

//         if (isVoiceEnabled) {
//             speak(currentText);
//         }
//     })
//     .catch(error => {
//         console.error("Fetch Error:", error); // Debug: Log the error
//         appendMessage('Bot', 'Oops! Something went wrong. Please try again.', 'ai-message');
//     });
// }

// Save chat in localStorage
function saveToSession(userMessage, aiResponse) {
    if (!chatSessions[activeSession]) chatSessions[activeSession] = [];
    chatSessions[activeSession].push({ user: userMessage, ai: aiResponse });

    localStorage.setItem(`chatSessions_${userId}`, JSON.stringify(chatSessions));
    updateSessionSidebar();
}

// Update sidebar with saved sessions
function updateSessionSidebar() {
    const historyList = document.getElementById('history-list');
    historyList.innerHTML = ''; // Clear existing sessions

    for (const sessionName in chatSessions) {
        const sessionItem = document.createElement('div');
        sessionItem.classList.add('history-item');

        const sessionNameElement = document.createElement('span');
        sessionNameElement.classList.add('session-name');
        sessionNameElement.textContent = sessionName;
        sessionNameElement.setAttribute('data-session', sessionName); // Add data-session attribute
        sessionItem.appendChild(sessionNameElement);

        const sessionActions = document.createElement('div');
        sessionActions.classList.add('session-actions');

        const renameBtn = document.createElement('button');
        renameBtn.classList.add('rename-btn');
        renameBtn.textContent = '✏️';
        renameBtn.addEventListener('click', (e) => {
            e.stopPropagation(); // Prevent session from loading when renaming
            renameSession(sessionName);
        });
        sessionActions.appendChild(renameBtn);

        const deleteBtn = document.createElement('button');
        deleteBtn.classList.add('delete-btn');
        deleteBtn.textContent = '🗑️';
        deleteBtn.addEventListener('click', (e) => {
            e.stopPropagation(); // Prevent session from loading when deleting
            deleteSession(sessionName);
        });
        sessionActions.appendChild(deleteBtn);

        sessionItem.appendChild(sessionActions);

        sessionItem.addEventListener('click', () => loadSession(sessionName));
        historyList.appendChild(sessionItem);
    }
}

// Rename a session (inline editing)
function renameSession(sessionName) {
    const sessionItem = document.querySelector(`.history-item .session-name[data-session="${sessionName}"]`);
    if (!sessionItem) return;

    // Create an input field for editing
    const inputField = document.createElement('input');
    inputField.type = 'text';
    inputField.value = sessionName;
    inputField.classList.add('session-edit-input');

    // Replace the session name with the input field
    sessionItem.replaceWith(inputField);
    inputField.focus();

    // Save the new name when Enter is pressed or focus is lost
    inputField.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            saveRenamedSession(sessionName, inputField.value);
        }
    });

    inputField.addEventListener('blur', () => {
        saveRenamedSession(sessionName, inputField.value);
    });
}

// Save the renamed session
function saveRenamedSession(oldName, newName) {
    if (!newName || newName === oldName) {
        // If the name is invalid or unchanged, revert to the old name
        updateSessionSidebar();
        return;
    }

    // Update the session name in the chatSessions object
    chatSessions[newName] = chatSessions[oldName];
    delete chatSessions[oldName];

    // Update activeSession if necessary
    if (activeSession === oldName) {
        activeSession = newName;
        localStorage.setItem(`activeSession_${userId}`, activeSession);
    }

    // Save the updated sessions to localStorage
    localStorage.setItem(`chatSessions_${userId}`, JSON.stringify(chatSessions));

    // Update the sidebar to reflect the changes
    updateSessionSidebar();
}

// Delete a session
function deleteSession(sessionName) {
    if (confirm(`Are you sure you want to delete "${sessionName}"?`)) {
        delete chatSessions[sessionName];

        // If the deleted session was the active session, switch to the default session
        if (activeSession === sessionName) {
            activeSession = 'Default';
            localStorage.setItem(`activeSession_${userId}`, activeSession);
        }

        // Save the updated sessions to localStorage
        localStorage.setItem(`chatSessions_${userId}`, JSON.stringify(chatSessions));

        // Update the sidebar to reflect the changes
        updateSessionSidebar();

        // Clear the chat box if the deleted session was active
        if (activeSession === 'Default') {
            const chatBox = document.getElementById('chat-box');
            chatBox.innerHTML = '';
        }
    }
}

// Load selected session's chat
function loadSession(sessionName) {
    activeSession = sessionName;
    localStorage.setItem(`activeSession_${userId}`, activeSession);

    const chatBox = document.getElementById('chat-box');
    chatBox.innerHTML = ''; // Clear chat box

    chatSessions[sessionName].forEach(chat => {
        appendMessage('You', chat.user, 'user-message');
        appendMessage('AI', chat.ai, 'ai-message');
    });
}

// Create new session
function createNewSession() {
    // Generate a unique session name
    let sessionNumber = 1;
    let sessionName;
    
    do {
        sessionName = `Session ${sessionNumber}`;
        sessionNumber++;
    } while (chatSessions.hasOwnProperty(sessionName));
    
    // Initialize the new session
    chatSessions[sessionName] = [];
    localStorage.setItem(`chatSessions_${userId}`, JSON.stringify(chatSessions));

    // Set as active session
    activeSession = sessionName;
    localStorage.setItem(`activeSession_${userId}`, activeSession);
    
    // Update UI
    updateSessionSidebar();
    
    // Clear the chat box and show confirmation
    const chatBox = document.getElementById('chat-box');
    chatBox.innerHTML = '';
    appendMessage('System', `New session "${sessionName}" created`, 'system-message');
}



// Append message to chat box
function appendMessage(sender, message, messageClass) {
    const chatBox = document.getElementById('chat-box');
    const messageElement = document.createElement('div');
    messageElement.classList.add('message', messageClass);

    // Preserve line breaks and formatting
    const formattedMessage = message.replace(/\n/g, '<br>'); // Replace newlines with <br>
    messageElement.innerHTML = `<strong>${sender}:</strong> ${formattedMessage}`;

    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight;
}

// Toggle Sidebar
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('collapsed');
}

// Toggle Voice Function
function toggleVoice() {
    isVoiceEnabled = !isVoiceEnabled;
    const toggleButton = document.getElementById('voice-toggle-btn').querySelector('img');
    const mutedImg = toggleButton.getAttribute('data-muted');
    const volumeImg = toggleButton.getAttribute('data-volume');
    toggleButton.src = isVoiceEnabled ? volumeImg : mutedImg;

    if (isVoiceEnabled && currentText) {
        speak(currentText.substring(spokenIndex));
    } else if (!isVoiceEnabled && window.speechSynthesis.speaking) {
        window.speechSynthesis.cancel();
    }
}

// Speak Function
function speak(text) {
    if ('speechSynthesis' in window) {
        currentUtterance = new SpeechSynthesisUtterance(text);
        currentUtterance.onend = () => spokenIndex = currentText.length;
        currentUtterance.onboundary = (event) => {
            if (event.name === 'word') spokenIndex = event.charIndex;
        };
        window.speechSynthesis.speak(currentUtterance);
    } else {
        console.error('Text-to-Speech not supported in this browser.');
    }
}

// Initialize sidebar
updateSessionSidebar();

//let currentPromptType = 'general'; // default prompt

function changePrompt() {
    currentPromptType = document.getElementById('prompt-type').value;
    // Optional: You might want to notify the user the mode has changed
    console.log(`Prompt type changed to: ${currentPromptType}`);
    // You could add a visual notification like:
     alert(`Switched to ${document.getElementById('prompt-type').options[document.getElementById('prompt-type').selectedIndex].text} mode`);
}
// Global variable to store current prompt type


// Modified sendMessage function with prompt support
function sendMessage() {
    const message = userInput.value.trim();
    if (message === "") return;

    appendMessage('You', message, 'user-message');
    userInput.value = '';
    userInput.style.height = 'auto';

    const promptType = document.getElementById('prompt-type').value;
    const customPrompt = promptType === "custom" ? customPromptText : null;

    fetch('http://127.0.0.1:5000/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            user_input: message,
            user_id: userId,
            session_name: activeSession,
            prompt_type: promptType,
            custom_prompt: customPrompt
        })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        console.log("Response Data:", data);
        appendMessage('AI', data.response, 'ai-message');

        currentText = data.response;
        spokenIndex = 0;

        saveToSession(message, data.response);

        if (isVoiceEnabled) {
            speak(currentText);
        }
    })
    .catch(error => {
        console.error("Fetch Error:", error);
        appendMessage('Bot', 'Oops! Something went wrong. Please try again.', 'ai-message');
    });
}

// Function to handle prompt selection change
function changePrompt() {
    currentPromptType = document.getElementById('prompt-type').value;
    // Optional: Add visual feedback
    const promptName = document.getElementById('prompt-type').options[document.getElementById('prompt-type').selectedIndex].text;
    showToast(`Mode changed to: ${promptName}`);
    console.log(`Prompt type changed to: ${currentPromptType}`);
}

// Optional: Helper function to show toast notifications
function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast-notification';
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('fade-out');
        setTimeout(() => toast.remove(), 500);
    }, 3000);
}

function changePrompt() {
    const select = document.getElementById('prompt-type');
    currentPromptType = select.value;
    const promptName = select.options[select.selectedIndex].text;
    
    showNotification(`Mode changed to: ${promromptName}`);
}


// coustem prompt
document.addEventListener('DOMContentLoaded', function() {
    const promptSelect = document.getElementById('prompt-type');
    const modal = document.getElementById('custom-prompt-modal');
    const closeBtn = document.querySelector('.close-modal');
    const submitBtn = document.getElementById('submit-custom-prompt');
    const customPromptInput = document.getElementById('custom-prompt-input');
    
    // Load saved custom prompt if exists
    const savedPrompt = localStorage.getItem('customPrompt');
    if (savedPrompt) {
        customPromptInput.value = savedPrompt;
    }

    promptSelect.addEventListener('change', function() {
        if (this.value === 'custom') {
            modal.style.display = 'block';
            // Don't reset the selection - allow editing
            customPromptInput.focus();
        } else {
            currentPromptType = this.value;
            const promptName = this.options[this.selectedIndex].text;
            showNotification(`Mode changed to: ${promptName}`);
        }
    });
    
    closeBtn.onclick = function() {
        modal.style.display = 'none';
        // Reset selector to current prompt type when closed without saving
        promptSelect.value = currentPromptType;
    }
    
    submitBtn.onclick = function() {
        const customPrompt = customPromptInput.value.trim();
        if (customPrompt) {
            localStorage.setItem('customPrompt', customPrompt);
            currentPromptType = 'custom';
            // Update the select element to show 'custom' is selected
            promptSelect.value = 'custom';
            showNotification('Custom prompt saved!');
            modal.style.display = 'none';
        } else {
            showNotification('Please enter a custom prompt');
        }
    }
    
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = 'none';
            // Reset selector to current prompt type when clicking outside
            promptSelect.value = currentPromptType;
        }
    }

    // Add edit button functionality
    const editPromptBtn = document.createElement('button');
    editPromptBtn.innerHTML = '✏️';
    editPromptBtn.className = 'edit-prompt-btn';
    editPromptBtn.title = 'Edit custom prompt';
    editPromptBtn.onclick = function() {
        modal.style.display = 'block';
        customPromptInput.focus();
    };
    
    // Add edit button next to the prompt selector
    promptSelect.parentNode.appendChild(editPromptBtn);
    
    function showNotification(message) {
        // Implement your existing notification system here
        console.log(message);
        // Or use your existing toast notification function
    }
});

document.getElementById('submit-custom-prompt').addEventListener('click', function() {
    customPromptText = document.getElementById('custom-prompt-input').value.trim();
    if (customPromptText) {
        localStorage.setItem('customPrompt', customPromptText);
        currentPromptType = 'custom';
        document.getElementById('prompt-type').value = 'custom'; // Update the select element
        showNotification('Custom prompt activated!');
        document.getElementById('custom-prompt-modal').style.display = 'none';
    }
});

function appendMessage(sender, message, messageClass) {
    const chatBox = document.getElementById('chat-box');
    const messageElement = document.createElement('div');
    messageElement.classList.add('message', messageClass);

    // First process code blocks to protect them
    let formattedMessage = message
        .replace(/```(\w*)([\s\S]*?)```/g, processCodeBlocks)
        .replace(/`([^`]+)`/g, '<code class="inline-code">$1</code>');

    // Process tables
    formattedMessage = formattedMessage.replace(/\|([^\n]+)\|?\n\|([^\n]+)\|?\n((?:\|([^\n]+)\|?\n?)+)/g, function(match, header, separator, rows) {
        // Process header row
        const headers = header.split('|').map(h => h.trim()).filter(h => h);
        const aligns = separator.split('|').map(s => {
            const col = s.trim();
            if (col.startsWith(':') && col.endsWith(':')) return 'center';
            if (col.endsWith(':')) return 'right';
            return 'left';
        }).filter(a => a);
        
        // Process data rows
        const rowData = rows.split('\n').filter(r => r.trim()).map(row => {
            return row.split('|').map(c => c.trim()).filter(c => c);
        });

        // Build HTML table
        let tableHtml = '<div class="markdown-table-container"><table class="markdown-table"><thead><tr>';
        
        // Add headers
        headers.forEach((h, i) => {
            const align = aligns[i] || 'left';
            tableHtml += `<th style="text-align: ${align}">${h}</th>`;
        });
        tableHtml += '</tr></thead><tbody>';
        
        // Add rows
        rowData.forEach(row => {
            tableHtml += '<tr>';
            row.forEach((cell, i) => {
                const align = aligns[i] || 'left';
                tableHtml += `<td style="text-align: ${align}">${cell}</td>`;
            });
            tableHtml += '</tr>';
        });
        
        tableHtml += '</tbody></table></div>';
        return tableHtml;
    });

    // Then process the rest of the formatting
    formattedMessage = formattedMessage
        // Process bold (**text**)
        .replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>')
        // Process links
        .replace(/\[([^\]]+)\]\(([^)]+)\)/g, 
            '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>')
        // Process bullet points (- or * at start of line)
        .replace(/^(\s*[-*]\s+)([^\n]*)/gm, function(match, bullets, content) {
            // Skip if already processed as a list item
            if (content.includes('<li>')) return match;
            return '<li>' + content + '</li>';
        })
        // Wrap consecutive list items in <ul> if not already wrapped
        .replace(/((?:<li>.*?<\/li>\s*)+)/g, function(match) {
            return match.startsWith('<ul>') ? match : '<ul>' + match + '</ul>';
        })
        // Convert remaining newlines to <br> (except in code/pre)
        .replace(/\n/g, function(match, offset, string) {
            const before = string.substring(0, offset);
            if (before.includes('<pre') && !before.includes('</pre>')) return match;
            if (before.includes('<code') && !before.includes('</code>')) return match;
            if (before.includes('<li>') && !before.includes('</li>')) return match;
            if (before.includes('<table') && !before.includes('</table>')) return match;
            return '<br>';
        });
    
    messageElement.innerHTML = `<strong>${sender}:</strong> ${formattedMessage}`;
    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight;
}

function processCodeBlocks(match, language, code) {
    const codeId = 'code-' + Math.random().toString(36).substr(2, 9);
    const langDisplay = language || 'text';
    return `
    <div class="code-container">
        <div class="code-header">
            <span class="language-label">${langDisplay}</span>
            <button class="copy-btn" onclick="copyCode('${codeId}')">Copy</button>
        </div>
        <pre><code id="${codeId}">${code.trim()}</code></pre>
    </div>`;
}
// Add this new function to handle copying
function copyCode(codeId) {
    const codeElement = document.getElementById(codeId);
    const textToCopy = codeElement.innerText;
    
    navigator.clipboard.writeText(textToCopy).then(() => {
        // Show copied notification
        const notification = document.createElement('div');
        notification.className = 'copy-notification';
        notification.textContent = 'Copied!';
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 2000);
    }).catch(err => {
        console.error('Failed to copy: ', err);
    });
}